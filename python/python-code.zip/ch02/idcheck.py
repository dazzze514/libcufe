id = input("Please input your user name (3 chars): ")
digits = "0123456789"
alphas = 'abcdefghijklmnopqrstuvwxyz'
special = "_"
isValid = id[0] in alphas
isValid = isValid and (id[1] in digits+alphas+special)
isValid = isValid and (id[2] in digits+alphas)
print(isValid)
