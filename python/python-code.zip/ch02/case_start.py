myName = input("Please input your name (last,first): ").strip()
myBirthday = input("Please input your birthday(mm/dd/yyyy): ").strip()
myUserName = input("Please input your user name with 3 chars: ").strip()
myCourse = input("Please input your course: ").strip()
myBook = input("Please input your book (title,publisher,year): ").strip()
 
birthMonth = int(myBirthday.split("/")[0])
birthDay = int(myBirthday.split("/")[1])
birthYear = int(myBirthday.split("/")[2])
