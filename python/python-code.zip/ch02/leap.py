birthYear = int(input("Please input your birth year: "))
isLeapYear = birthYear%4==0
isLeapYear = isLeapYear and birthYear%100!=0
isLeapYear = isLeapYear or birthYear%400==0
print(isLeapYear)
