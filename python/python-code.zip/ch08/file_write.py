f = open("test.txt","w")
f.write("This text will be written into the test.txt.\n")
f.write("This is the second line in the test.txt.\n")
f.close()
