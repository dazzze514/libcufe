with open("test.txt",'r') as f:
    begin = f.tell()
    print("current cursor: %d"%begin)
    content = f.readlines()
    print(content)
    end = f.tell()
    print("current cursor: %d"%end)
    
