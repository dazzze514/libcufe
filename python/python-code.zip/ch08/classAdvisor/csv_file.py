from persons.classAdvisor import ClassAdvisor
from persons.student import Student
import csv

def read_students(student_list):
    """得到学生实例列表"""
    students = []
    for i in range(len(student_list)):
        s = student_list[i]
        students.append(Student(s['name'], s['gender'], s['height'], s['weight'], s['stu_id'],
		                                s['school'], s['major']))
    return students

try:
    filename = "student_list.csv"
    f = open(filename, 'r')
    r = csv.reader(f)
    student_list = []
    for eachrow in r:
        student_list.append(eachrow)
    f.close()
    keys = student_list[0]
    values = student_list[1:]
    student_dict = [dict(zip(keys,eachvalue)) for eachvalue in values]
    students = read_students(student_dict)
    yue = ClassAdvisor('王月', '男', 1.62, 70, '2014312200', '信息', '信息管理', '信管18', students)
    print('（1）给学生建议：')
    yue.advice_to_student('认真学习', students[0])
    yue.advice_to_student('要读文献', students[1])
    print('（2）{}班级介绍：'.format(yue.lead_class))
    yue.ask_class_introduce()    
except FileNotFoundError as e:
    print("Can not open file %s." %filename)
