import json
import csv

jsonname = "student_list.json"
csvname = "student_list.csv"
    
try:
    f = open(jsonname, 'r',encoding='utf-8')
    student_list = json.load(f)
    f.close()
    f = open(csvname, 'w', newline='')
    w = csv.writer(f)      
    w.writerow(student_list[0].keys())
    for each in student_list:
        w.writerow(each.values())
    f.close()
except FileNotFoundError as e:
    print("Can not open file %s." %jsonname)


    

