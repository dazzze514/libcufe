import pickle

class TestClass(object):
    def __init__(self):
        self.name = "test"
        self.size = 3
        
c = TestClass()

f = open("test_bin.txt","bw")
pickle.dump(c,f)
f.close()
