fileName = input("Please input file name: ")
try:
    f = open(fileName,'r')
    content = f.readlines()
    f.close()
    dividend =  float(content[0])
    divisor = float(content[1])
    result =  dividend/divisor
    print("%s/%s=%s"%(dividend,divisor,result))
except FileNotFoundError as e:
    print("File not found: %s"%e)
except ZeroDivisionError as e:
    print("Divide by zero: %s"%e)
except Exception as e:
    print(e)
    


        

    
