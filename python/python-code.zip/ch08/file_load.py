import pickle

class TestClass(object):
    def __init__(self):
        self.name="test"
        self.size=3

f = open("test_bin.txt",'rb')
c = pickle.load(f)
print(c,c.name,c.size)
f.close()
