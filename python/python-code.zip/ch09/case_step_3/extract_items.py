import re
import os
import json
from spider_taobao import spider_taobao

class Item(object):
    def __init__(self, info):
        self.nid = info[0]
        self.price = info[1]
        self.producer = info[2]
        self.location = info[3]
        self.category = info[4]
        self.sale = info[5]

class ExtractItems(object):
    def __init__(self, kw='男鞋'):
        url = 'https://s.taobao.com/search?q=%s' % kw
        self.crawler = spider_taobao()  # 初始化一个爬虫对象
        self.html = self.crawler.get_html(url)
        self.category = kw

    def next(self, batch):
        url = 'https://s.taobao.com/search?q=%s&s=%d' % (self.category, batch)
        self.html = self.crawler.get_html(url)

    def get_prices(self):
        #获取商品价格
        raw_texts = re.findall(r'\"view_price\"\:\"[\d\.]*\"', self.html)
        prices = []
        for t in raw_texts:
            _, price = t.replace('"', '').split(':')
            prices.append(price)
        return prices

    def get_sales(self):
        #获取成交数量
        raw_texts = re.findall(r'\"view_sales\"\:\".*?\"', self.html)
        sales = []
        for t in raw_texts:
            _, sale = t.replace('"', '').split(':')
            sales.append(sale.replace(u'人付款', ''))
        return sales

    def get_nids(self):
        # 获取商品在淘宝系统中的id
        raw_texts = re.findall(r'\"nid\"\:\"[\d\.]*\"', self.html)
        nids = []
        for t in raw_texts:
            _, nid = t.replace('"', '').split(':')
            nids.append(nid)
        return nids

    def get_producers(self):
        #获取商家昵称
        raw_texts = re.findall(r'\"nick\"\:\".*?\"', self.html)
        prods = []
        for t in raw_texts:
            _, prod = t.replace('"', '').split(':')
            prods.append(prod)
        return prods

    def get_locations(self):
        #获取商品所在地
        raw_texts = re.findall(r'\"item_loc\"\:\".*?\"', self.html)
        locs = []
        for t in raw_texts:
            _, loc = t.replace('"', '').split(':')
            locs.append(loc)
        return locs

    def extract(self, max_num=1):
        #抓取给定个数的商品
        items = []
        page = 0
        while max_num > 0:
            nids = self.get_nids()
            prices = self.get_prices()
            producers = self.get_producers()
            locations = self.get_locations()
            sales = self.get_sales()
            if len(nids) < 1:  # 如果没有提取到任何商品id,结束爬取
                break
            for idx, nid in enumerate(nids):
                it = Item([nid, prices[idx], producers[idx], locations[idx], self.category, sales[idx]])
                items.append(it)
            page +=1
            self.next(len(nids)*page)
            max_num -= len(nids)
        return items

def save(data, output_dir='.'):
    # 以json文件形式保存抓取结果 
    attributes = []
    for it in data:
        attr = {'nid': it.nid, 'category': it.category, 'price': it.price, 'producer': it.producer,
                'location': it.location, 'sale': it.sale}
        attributes.append(attr)
    with open(os.path.join(output_dir, 'item_attributes.json'), 'w') as f:
        json.dump(attributes, f, ensure_ascii=False)
    print('get %d items\' attributes' % (len(attributes)))
    print('save attributes of items on %s' % (os.path.join(output_dir, 'item_attributes.json')))
