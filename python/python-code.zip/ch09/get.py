import requests 
url= 'https://s.taobao.com/search?q=男鞋'
headers = {
    'Accept':'text/html,application/xhtml+xml,application/x',
    'Accept-encoding': 'gzip, deflate, br',
    'Accept-Language':'zh-CN,zh;q=0.9,en;q=0.8',
    'Referer':'https://extract_items.taobao.com/extract_items.htm',
    'Upgrade-insecure-requests': '1',
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
    'Connection':'keep-alive',
    'content-type':'utf-8',
    }
r = requests.get(url, headers=headers) 
print(r.url)
print(t.text)
