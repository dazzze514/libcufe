# encoding:UTF-8
import re
# 将正则表达式编译成Pattern对象
pattern = re.compile('[A-Za-z0-9\._+]+@[A-Za-z]+\.(com|org|edu|net)')
# 使用Pattern匹配文本，获得匹配结果，无法匹配时将返回None
match = pattern.match('liming@163.com')
if match:
    print(match.group())
else:
    print("Not Match!")
