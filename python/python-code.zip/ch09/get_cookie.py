import requests 
url= 'https://s.taobao.com/search?q=男鞋'
headers = {
    'Accept':'text/html,application/xhtml+xml,application/x',
    'Accept-encoding': 'gzip, deflate, br',
    'Accept-Language':'zh-CN,zh;q=0.9,en;q=0.8',
    'Referer':'https://extract_items.taobao.com/extract_items.htm',
    'Upgrade-insecure-requests': '1',
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
    'Connection':'keep-alive',
    'content-type':'utf-8',
    'cookie': 'cna=2CVAFBY2mzcCAY0e21zhwSYF; t=ea337e3d571c6b18846bb6d56b558bce; hng=CN%7Czh-CN%7CCNY%7C156; thw=cn; tg=0; enc=4sQ0wemMLtA4spUnE0TQS0pfX9kl%2BTIwVqD9ruEO17vRmF%2FyMV3QxOmP1dC3lrdwvPHXnC3TmJvnjQpMUEGdCA%3D%3D; x=e%3D1%26p%3D*%26s%3D0%26c%3D0%26f%3D0%26g%3D0%26t%3D0%26__ll%3D-1%26_ato%3D0; JSESSIONID=CDCD4C65BF7F469FBDA20C294D568CFE; cookie2=154c2f65535e5f4d4e6fb3d22e4fc4bd; v=0; _tb_token_=e33eeee7d07ee; unb=135340298; uc1=cookie16=URm48syIJ1yk0MX2J7mAAEhTuw%3D%3D&cookie21=UtASsssme%2BBq&cookie15=UIHiLt3xD8xYTw%3D%3D&existShop=false&pas=0&cookie14=UoTZ48xkBZ%2BnMw%3D%3D&tag=8&lng=zh_CN; sg=88a; _l_g_=Ug%3D%3D; skt=3c15bdf6b4db0f52; publishItemObj=Ng%3D%3D; cookie1=BdZV0S2IUmIh6%2BClEl92vL3uNXlyzHNICsUH9xXoEjc%3D; csg=dc60a8bc; uc3=vt3=F8dBy3qOMRwQM6xzwzM%3D&id2=UoLZXzB15CmN&nk2=GcAxdWUt6x4gnmlZVDeT0w%3D%3D&lg2=V32FPkk%2Fw0dUvg%3D%3D; existShop=MTU1Nzk3MjIxOA%3D%3D; tracknick=zhangning75_2008; lgc=zhangning75_2008; _cc_=Vq8l%2BKCLiw%3D%3D; dnk=zhangning75_2008; _nk_=zhangning75_2008; cookie17=UoLZXzB15CmN; mt=ci=0_0&np=; isg=BODgX6TYqP_SRxT7yU4dPtwise4e_c6w6VqjH1rxrPuOVYB_AvmUQ7Zn7b3wfnyL; l=bB_wFSEqvVLDU9ZSBOCanurza77OSIRYYuPzaNbMi_5BJ6T6Vg7OlpHTrF96Vj5RstTB4ErWpCv9-etkZ'
    }
r = requests.get(url, headers=headers) 
print(r.url)
print(r.text)
