import re
import os
import json
from spider_taobao import spider_taobao

class Item(object):
    def __init__(self, product_id):
        self.nid = product_id

class ExtractItems(object):
    def __init__(self, kw='男鞋'):
        url = 'https://s.taobao.com/search?q=%s' % kw
        self.crawler = spider_taobao()  # 初始化一个爬虫对象
        self.html = self.crawler.get_html(url)
        self.category = kw

    def next(self, batch):
        url = 'https://s.taobao.com/search?q=%s&s=%d' % (self.category, batch)
        self.html = self.crawler.get_html(url)

    def get_nids(self):
        #获取商品在淘宝系统中的id
        raw_texts = re.findall(r'\"nid\"\:\"[\d\.]*\"', self.html)
        nids = []
        for t in raw_texts:
            _, nid = t.replace('"', '').split(':')
            nids.append(nid)
        return nids

    def extract(self, max_num=1):
       # 抓取给定个数的商品    
        items = []
        page = 0
        while max_num > 0:
            nids = self.get_nids()
            if len(nids) < 1:  # 如果没有提取到任何商品id,结束爬取
                break
            for idx, nid in enumerate(nids):
                it = Item(nid)
                items.append(it)
            page +=1
            self.next(len(nids)*page)
            max_num -= len(nids)
        return items

def save(data, output_dir='.'):
    # 以json文件形式保存抓取结果
    attributes = []
    for it in data:
        attr = {'nid': it.nid}
        attributes.append(attr)
    with open(os.path.join(output_dir, 'item_attributes.json'), 'w') as f:
        json.dump(attributes, f)
    print('get %d items\' attributes' % (len(attributes)))
    print('save attributes of items on %s' % (os.path.join(output_dir, 'item_attributes.json')))
