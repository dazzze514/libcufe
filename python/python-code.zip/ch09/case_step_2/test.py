import sys
from extract_items import ExtractItems
from extract_items import save

'''
sys.argv[1]:the keyword of items’ category
sys.argv[2]:the max number of items that we want to catch
sys.argv[3]:the dir path that the result files saving
'''

if __name__ == '__main__':
    
    keyword = '男鞋'
    max_num = 150
    output_dir = '.'
    
    if len(sys.argv)>1:
        keyword = sys.argv[1]
        if len(sys.argv)>2:
            max_num = int(sys.argv[2])
            if len(sys.argv)>3:
                output_dir = sys.argv[3]
        
    extractor = ExtractItems(keyword)
    items = extractor.extract(max_num)
    save(items,output_dir)
