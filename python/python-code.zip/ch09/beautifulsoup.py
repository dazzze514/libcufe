import lxml
from bs4 import BeautifulSoup

htmlf=open('astronomy.htm','r',encoding="utf-8")
html=htmlf.read()

bs = BeautifulSoup(html, 'lxml') #设置以lxml为匹配引擎
print(bs.prettify())#打印出html内容
print(bs.head.title)#打印网页标题的标签
print(bs.head.title.string)#打印网页标题的内容
print(bs.body.h1)#打印1号标题的标签
print(bs.body.h1.string)#打印1号标题的内容
