import requests
print(requests.get('https://github.com'))
print(requests.get('https://kennethreitz.com',cert=('/path/server.crt','/path/key')))
