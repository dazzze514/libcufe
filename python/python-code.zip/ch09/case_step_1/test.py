from extract_items import ExtractItems
from extract_items import save

if __name__ == '__main__':        
    extractor = ExtractItems('男鞋')
    items = extractor.extract()
    save(items)
