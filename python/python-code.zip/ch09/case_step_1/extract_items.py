import re
import os
import json
from spider_taobao import spider_taobao

class Item(object):
    def __init__(self, product_id):
        self.nid = product_id

class ExtractItems(object):
    def __init__(self, kw='男鞋'):
        url = 'https://s.taobao.com/search?q=%s' % kw
        self.crawler = spider_taobao()  # 初始化一个爬虫对象
        self.html = self.crawler.get_html(url)
        self.category = kw

    def get_nids(self):
        #获取商品在淘宝系统中的id
        raw_texts = re.findall(r'\"nid\"\:\"[\d\.]*\"', self.html)
        nids = []
        for t in raw_texts:
            _, nid = t.replace('"', '').split(':')
            nids.append(nid)
        return nids

    def extract(self):
        # 抓取给定个数的商品    
        items = []
        nids = self.get_nids()
        for idx, nid in enumerate(nids):
            it = Item(nid)
            items.append(it)
        return items

def save(data):
    # 以json文件形式保存抓取结果
    attributes = []
    for it in data:
        attr = {'nid': it.nid}
        attributes.append(attr)
    with open('item_attributes.json', 'w') as f:
        json.dump(attributes, f)
    print('get and save %d items\' attributes' % (len(attributes)))
