import requests
s = requests.session()
r = s.get('https://httpbin.org/cookies/set/sessioncookie/123')
r = s.get('https://httpbin.org/cookies')
print(r.text)
