from urllib.request import urlopen
html=urlopen("http://www.pythonscraping.com/pages/page3.html")
print(html.read())
