from persons.person import Person
class Student(Person):
    """对大学生的一个简单表示"""
    num_of_students = 0  # 类属性：记录学生实例个数

    def __init__(self, name, gender, height, weight, stu_id, school, major):
        Person.__init__(self, name, gender, height, weight)
        self.stu_id = stu_id  # 学号
        self.school = school  # 学院
        self.major = major  # 专业
        self.advice_list = []
        Student.num_of_students += 1  # 增加学生实例个数

    @classmethod
    def get_num_of_students(cls):
        """返回Student类的实例个数"""
        return cls.num_of_students

    def introduce_oneself(self):
        """重写Student类的自我介绍方法"""
        print("我的名字叫{}，来自{}学院{}专业。".format(self.name, self.school, self.major))

    def receive_advice(self, teacher_name, advice):
        self.advice_list.append(advice)
        print('学生{}收到{}老师的建议：{}。'.format(self.name, teacher_name, advice))