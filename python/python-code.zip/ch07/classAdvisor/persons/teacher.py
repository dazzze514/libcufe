from persons.person import Person
class Teacher(Person):
    """对大学教师的一个简单表示"""
    num_of_teachers = 0  # 类属性：记录Teacher实例个数

    def __init__(self, name, gender, height, weight, job_id, school, department):
        Person.__init__(self, name, gender, height, weight)
        self.job_id = job_id  # 工号
        self.school = school  # 学院
        self.department = department  # 部门
        Teacher.num_of_teachers += 1  # 记录Teacher实例个数

    @classmethod
    def get_num_of_teachers(cls):
        """输出Teacher类的实例个数"""
        print("目前Teacher类已创建{}个实例".format(cls.num_of_teachers))

    def ask_introduce(self, student):
        """教师请学生做自我介绍"""
        student.introduce_oneself()

    def advice_to_student(self, advice, student):
        """教师给一个学生建议"""
        student.receive_advice(self.name, advice)
