
from others.health import Health
class Person(object):
    """对人的一个简单表示"""
    num_of_persons = 0  # 类属性：记录实例个数

    def __init__(self, name, gender, height, weight):
        """构造器方法，设置属性的初始值"""
        self.name = name  # 姓名
        self.gender = gender  # 性别
        self.health = Health(height, weight)  # 健康状况
        Person.num_of_persons += 1  # 计算Person实例个数

    def introduce_oneself(self):
        """自我介绍方法，格式化输出自我介绍"""
        print("我的名字叫{}，我是一位{}士。".format(self.name, self.gender))

    @classmethod
    def get_num_of_persons(cls):
        """返回所创建的Person实例个数"""
        return cls.num_of_persons

    def test_bmi(self):
        """输出体质状况"""
        bmi = self.health.get_bmi()
        print("你（{}）的BMI是{}，显示{}。".format(self.name, round(bmi[0],1), bmi[1]))