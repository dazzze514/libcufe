from persons.teacher import Teacher
class ClassAdvisor(Teacher):
    """对大学班主任的一个简单表示"""

    def __init__(self, name, gender, height, weight, job_id, school, department, lead_class, students):
        Teacher.__init__(self, name, gender, height, weight, job_id, school, department)
        self.lead_class = lead_class  # 所带班级
        self.students = students  # 学生列表

    def ask_class_introduce(self):
        """请班级的每个同学自我介绍"""
        for i in range(len(self.students)):
            self.ask_introduce(self.students[i])


def read_students(student_list):
    """得到学生实例列表"""
    students = []
    for i in range(len(student_list)):
        s = student_list[i]
        students.append(Student(s['name'], s['gender'], s['height'], s['weight'], s['stu_id'],
                                s['school'], s['major']))
    return students