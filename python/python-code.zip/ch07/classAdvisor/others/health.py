class Health():
    """健康测评器"""

    def __init__(self, height, weight):
        """构造器方法，设置属性的初始值"""
        self.height = height  # 身高（米）
        self.weight = weight  # 体重（公斤）

    def get_bmi(self):
        """计算BMI返回体质结果"""
        bmi = self.weight / (self.height ** 2)
        if bmi < 18.5:
            result = [bmi, "过轻"]
        elif bmi < 24:
            result = [bmi, "正常"]
        elif bmi < 27:
            result = [bmi, "过重"]
        elif bmi < 32:
            result = [bmi, "肥胖"]
        else:
            result = [bmi, "非常肥胖"]
        return result