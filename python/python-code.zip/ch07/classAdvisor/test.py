from persons.classAdvisor import ClassAdvisor
from persons.student import Student

def read_students(student_list):
    """得到学生实例列表"""
    students = []
    for i in range(len(student_list)):
        s = student_list[i]
        students.append(Student(s['name'], s['gender'], s['height'], s['weight'], s['stu_id'],
                                s['school'], s['major']))
    return students

student_list = [{'name': '赵甲', 'gender': '男', 'height': 1.65, 'weight': 60, 'stu_id': '2018312201', 'school': '信息', 'major': '信息管理'},
                {'name': '钱乙', 'gender': '女', 'height': 1.75, 'weight': 70, 'stu_id': '2018312202', 'school': '金融', 'major': '金融学'},
                {'name': '孙丙', 'gender': '男', 'height': 1.85, 'weight': 80, 'stu_id': '2018312203', 'school': '金融', 'major': '金融工程'},
                {'name': '李丁', 'gender': '女', 'height': 1.95, 'weight': 90, 'stu_id': '2018312204', 'school': '会计', 'major': '财务会计'},
                {'name': '周戊', 'gender': '男', 'height': 1.65, 'weight': 60, 'stu_id': '2018312205', 'school': '财政', 'major': '财政学'},
                {'name': '吴己', 'gender': '女', 'height': 1.75, 'weight': 70, 'stu_id': '2018312206', 'school': '税务', 'major': '税收学'},
                {'name': '郑庚', 'gender': '男', 'height': 1.85, 'weight': 80, 'stu_id': '2018312207', 'school': '保险', 'major': '保险学'},
                {'name': '王辛', 'gender': '女', 'height': 1.65, 'weight': 60, 'stu_id': '2018312208', 'school': '统数', 'major': '统计学'},
                {'name': '冯壬', 'gender': '男', 'height': 1.75, 'weight': 70, 'stu_id': '2018312209', 'school': '经济', 'major': '经济学'},
                {'name': '陈癸', 'gender': '女', 'height': 1.85, 'weight': 80, 'stu_id': '2018312210', 'school': '文传', 'major': '视觉传达'}
               ]

students = read_students(student_list)
yue = ClassAdvisor('王月', '男', 1.62, 70, '2014312200', '信息', '信息管理', '信管18', students)
print('（1）给学生建议：')
yue.advice_to_student('认真学习', students[0])
yue.advice_to_student('要读文献', students[1])
print('（2）{}班级介绍：'.format(yue.lead_class))
yue.ask_class_introduce()
