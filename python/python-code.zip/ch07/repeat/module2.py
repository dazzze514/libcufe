repeat = 2
def get_repeat():
    return repeat
print("repeat in module2 is %s"%get_repeat())
