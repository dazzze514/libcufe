repeat = 3
def get_repeat():
    return repeat
if __name__=="__main__":
    print("repeat in module1 is %s"%get_repeat())
