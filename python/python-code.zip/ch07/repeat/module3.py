from module1 import repeat as r1
from module2 import repeat as r2
repeat = r1 * r2
def get_repeat():
    return repeat
print("repeat in module3 is %s"%get_repeat())
