import numpy as np

a=np.random.randint(1,100,size=[3,3])
b=np.random.randint(1,100,size=[3,3])
print("a = \n%s"%(a))
print("b = \n%s"%(b))
print("a * b = \n%s"%(a*b))
print("a + b = \n%s"%(a+b))
