class Health():
    """健康状况"""

    def __init__(self, height, weight):
        """构造器方法，设置属性的初始值"""
        self.height = height  # 身高（米）
        self.weight = weight  # 体重（公斤）

    def get_bmi(self):
        """计算BMI返回体质结果"""
        bmi = self.weight / (self.height ** 2)
        if bmi < 18.5:
            result = [bmi, "过轻"]
        elif bmi < 24:
            result = [bmi, "正常"]
        elif bmi < 27:
            result = [bmi, "过重"]
        elif bmi < 32:
            result = [bmi, "肥胖"]
        else:
            result = [bmi, "非常肥胖"]
        return result

    def show_bmi(self):
        """输出BMI状况"""
        bmi = self.get_bmi()
        print("BMI是{}，显示{}。".format(round(bmi[0],1), bmi[1]))

class Person(object):
    """对人的一个简单表示"""
    num_of_persons = 0  # 类属性：记录实例个数

    def __init__(self, name, gender, height, weight):
        """构造器方法，设置属性的初始值"""
        self.name = name  # 姓名
        self.gender = gender  # 性别
        self.health = Health(height, weight)  # 健康状况
        Person.num_of_persons += 1  # 计算Person实例个数

    def introduce_oneself(self):
        """自我介绍方法，格式化输出自我介绍"""
        print("我的名字叫{}，我是一位{}士。".format(self.name, self.gender))

    @classmethod
    def get_num_of_persons(cls):
        """返回所创建的Person实例个数"""
        return cls.num_of_persons

    def test_bmi(self):
        """输出体质状况"""
        bmi = self.health.get_bmi()
        print("你（{}）的BMI是{}，显示{}。".format(self.name, round(bmi[0],1), bmi[1]))


class Student(Person):
    """对大学生的一个简单表示"""
    num_of_students = 0  # 类属性：记录学生实例个数

    def __init__(self, name, gender, height, weight, stu_id, school, major):
        Person.__init__(self, name, gender, height, weight)
        self.stu_id = stu_id  # 学号
        self.school = school  # 学院
        self.major = major  # 专业
        self.advice_list = []
        Student.num_of_students += 1  # 增加学生实例个数

    @classmethod
    def get_num_of_students(cls):
        """返回Student类的实例个数"""
        return cls.num_of_students
    
    def introduce_oneself(self):
        """重写Student类的自我介绍方法"""
        print("我的名字叫{}，我是一位{}士，我来自{}学院{}专业。".format(self.name, self.gender,
              self.school, self.major))

    def receive_advice(self, teacher_name, advice):
        print('学生{}收到{}老师的建议：{}。'.format(self.name, teacher_name, advice))
        self.advice_list.append(advice)

        
class Teacher(Person):
    """对大学教师的一个简单表示"""
    num_of_teachers = 0  # 类属性：记录Teacher实例个数

    def __init__(self, name, gender, height, weight, job_id, school, department):
        Person.__init__(self, name, gender, height, weight)
        self.job_id = job_id  # 工号
        self.school = school  # 学院
        self.department = department  # 部门
        Teacher.num_of_teachers += 1  # 记录Teacher实例个数

    @classmethod
    def get_num_of_teachers(cls):
        """输出Teacher类的实例个数"""
        print("目前Teacher类已创建{}个实例".format(cls.num_of_teachers))

    def ask_introduce(self, student):
        """教师请学生做自我介绍"""
        student.introduce_oneself()

    def advice_to_student(self, advice, student):
        """教师给一个学生建议"""
        student.receive_advice(self.name, advice)


class ClassAdvisor(Teacher):
    """对大学班主任的一个简单表示"""

    def __init__(self, name, gender, height, weight, job_id, school, department, lead_class, students):
        Teacher.__init__(self, name, gender, height, weight, job_id, school, department)
        self.lead_class = lead_class  # 所带班级
        self.students = students  # 学生列表

    def ask_class_introduce(self):
        """请班级的每个同学自我介绍"""
        for i in range(len(self.students)):
            self.ask_introduce(self.students[i])


def read_students(student_list):
    """得到学生实例列表"""
    students = []
    for i in range(len(student_list)):
        s = student_list[i]
        students.append(Student(s['name'], s['gender'], s['height'], s['weight'], s['stu_id'],
                                s['school'], s['major']))
    return students


student_list = [{'name': '赵甲', 'gender': '男', 'height': 1.65, 'weight': 60, 'stu_id': '2018312201', 'school': '信息', 'major': '信息管理'},
                {'name': '钱乙', 'gender': '女', 'height': 1.75, 'weight': 70, 'stu_id': '2018312202', 'school': '金融', 'major': '金融学'},
                {'name': '孙丙', 'gender': '男', 'height': 1.85, 'weight': 80, 'stu_id': '2018312203', 'school': '金融', 'major': '金融工程'},
                {'name': '李丁', 'gender': '女', 'height': 1.95, 'weight': 90, 'stu_id': '2018312204', 'school': '会计', 'major': '财务会计'},
                {'name': '周戊', 'gender': '男', 'height': 1.65, 'weight': 60, 'stu_id': '2018312205', 'school': '财政', 'major': '财政学'},
                {'name': '吴己', 'gender': '女', 'height': 1.75, 'weight': 70, 'stu_id': '2018312206', 'school': '税务', 'major': '税收学'},
                {'name': '郑庚', 'gender': '男', 'height': 1.85, 'weight': 80, 'stu_id': '2018312207', 'school': '保险', 'major': '保险学'},
                {'name': '王辛', 'gender': '女', 'height': 1.65, 'weight': 60, 'stu_id': '2018312208', 'school': '统数', 'major': '统计学'},
                {'name': '冯壬', 'gender': '男', 'height': 1.75, 'weight': 70, 'stu_id': '2018312209', 'school': '经济', 'major': '经济学'},
                {'name': '陈癸', 'gender': '女', 'height': 1.85, 'weight': 80, 'stu_id': '2018312210', 'school': '文传', 'major': '视觉传达'}]

students = read_students(student_list)
yue = ClassAdvisor('王月', '男', 1.62, 70, '2014312200', '信息', '信息管理', '信管18', students)
print('（1）给学生建议：')
yue.advice_to_student('认真学习', students[0])
yue.advice_to_student('要读文献', students[0])
print('（2）{}班级介绍：'.format(yue.lead_class))
yue.ask_class_introduce()
