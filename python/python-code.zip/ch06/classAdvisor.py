class Health(object):
    def __init__(self,sg,tz):
        self.height = sg
        self.weight = tz
    def get_bmi(self):
        bmi = self.weight / self.height**2
        if bmi<18.5:
            result = [bmi,"过轻"]
        elif 18<=bmi<24:
            result = [bmi,"正常"]
        elif 24<=bmi<28:
            result = [bmi,"过重"]
        elif 28<=bmi<32:
            result = [bmi,"肥胖"]
        else:
            result = [bmi,"非常肥胖"]
        return result
    def show_bmi(self):
        result=self.get_bmi()
        print("BMI是{}：{}！".format(round(result[0],1),result[1]))

class Person(object):
    num_of_persons = 0
    def __init__(self,xm,xb,sg,tz):
        self.name=xm
        self.gender=xb
        self.health=Health(sg,tz)
        Person.num_of_persons+=1
    def introduce_oneself(self):
        print("我叫{}，我是一位{}士。".format(self.name,self.gender))
    @classmethod
    def get_num_of_persons(cls):
        return cls.num_of_persons

class Student(Person):
    num_of_students = 0
    def __init__(self,xm,xb,sg,tz,xh,xy,zy):
        Person.__init__(self,xm,xb,sg,tz)
        self.stuNo=xh
        self.school=xy
        self.major=zy
        self.adviceList=[]
        Student.num_of_students+=1
    def introduce_oneself(self):
        print("我叫{}，我是一位{}学院{}专业{}生。".format(self.name,self.school,self.major,self.gender))
    @classmethod
    def get_num_of_students(cls):
        return cls.num_of_students
    def receive_advice(self,teacherName,advice):
        print("{}同学收到{}老师的建议：{}".format(self.name,teacherName,advice))
        self.adviceList.append(advice)
    def show_advice(self):
        for advice in self.adviceList:
            print(advice)

class Teacher(Person):
    num_of_teachers = 0
    def __init__(self,xm,xb,sg,tz,gh,xy,x):
        Person.__init__(self,xm,xb,sg,tz)
        self.teaNo=gh
        self.school=xy
        self.department=x
        Teacher.num_of_teachers+=1
    def introduce_oneself(self):
        print("我叫{}，我是一位{}学院{}系{}教师。".format(self.name,self.school,self.department,self.gender))
    @classmethod
    def get_num_of_teachers(cls):
        return cls.num_of_teachers
    def ask_introduce(self,student):
        print("{}老师请{}同学作自我介绍：".format(self.name,student.name))
        student.introduce_oneself()
    def send_advice(self,student,advice):
        print("{}老师给{}同学发出建议：{}".format(self.name,student.name,advice))
        student.receive_advice(self.name,advice)

class Advisor(Teacher):
    def __init__(self,xm,xb,sg,tz,gh,xy,x,bj,lb):
        Teacher.__init__(self,xm,xb,sg,tz,gh,xy,x)
        self.className=bj
        self.studentList=lb
    def ask_class_introduce(self):
        for student in self.studentList:
            self.ask_introduce(student)
    def send_class_advice(self,advice):
        for student in self.studentList:
            self.send_advice(student,advice)
    def check_class_bmi(self):
        for student in self.studentList:
            print(student.name+":")
            student.health.show_bmi()

def read_students(studDictList):
    studObjectList=[]
    for studDict in studDictList:
        studObjectList.append(Student(studDict['name'],
                                      studDict['gender'],studDict['height'],
                                      studDict['weight'],studDict['stu_id'],
                                      studDict['school'],studDict['major']))
    return studObjectList

student_list = [{'name': '赵甲', 'gender': '男', 'height': 1.65, 'weight': 60, 'stu_id': '2018312201', 'school': '信息', 'major': '信息管理'},
                {'name': '钱乙', 'gender': '女', 'height': 1.75, 'weight': 70, 'stu_id': '2018312202', 'school': '金融', 'major': '金融学'},
                {'name': '孙丙', 'gender': '男', 'height': 1.85, 'weight': 80, 'stu_id': '2018312203', 'school': '金融', 'major': '金融工程'},
                {'name': '李丁', 'gender': '女', 'height': 1.95, 'weight': 90, 'stu_id': '2018312204', 'school': '会计', 'major': '财务会计'},
                {'name': '周戊', 'gender': '男', 'height': 1.65, 'weight': 60, 'stu_id': '2018312205', 'school': '财政', 'major': '财政学'},
                {'name': '吴己', 'gender': '女', 'height': 1.75, 'weight': 70, 'stu_id': '2018312206', 'school': '税务', 'major': '税收学'},
                {'name': '郑庚', 'gender': '男', 'height': 1.85, 'weight': 80, 'stu_id': '2018312207', 'school': '保险', 'major': '保险学'},
                {'name': '王辛', 'gender': '女', 'height': 1.65, 'weight': 60, 'stu_id': '2018312208', 'school': '统数', 'major': '统计学'},
                {'name': '冯壬', 'gender': '男', 'height': 1.75, 'weight': 70, 'stu_id': '2018312209', 'school': '经济', 'major': '经济学'},
                {'name': '陈癸', 'gender': '女', 'height': 1.85, 'weight': 80, 'stu_id': '2018312210', 'school': '文传', 'major': '视觉传达'}]

students = read_students(student_list)

shan = Advisor('李珊', '女', 1.66, 55,
               '2016312200', '金融', '金融科技','金融实验班18',students)

shan.ask_class_introduce()
shan.send_class_advice("好好学习，天天向上！")
shan.check_class_bmi()


              

