def readMax():
 #读入一个最大整数，要求它是一个大于等于4的数。返回此数。
    while True:
        a = int(input('请输入一个大于等于4的最大整数：'))
        if a >=4:
            return a
        else:
            print('这不是一个大于等于4的数！')

def isPrime(x):
#判断一个数x是否为素数，若是，返回True；否则，返回False。
    if int(x) != x or x <2:
        return False
    for i in range(2,x-1):
        if x % i == 0:
            return False
    return True

for i in range(1,51):
    if isPrime(i):
        print(i)

def decompose(a):
#返回偶数a成功分解的两个素数；若不能分解，则返回[0, 0]。
    if a % 2 != 0 or a < 4:
        print(str(a) + '：这不是一个大于等于4的偶数！')
        return [0,0]
	    
    for i in range(2,a-1): #使用穷举法分解该偶数
        if isPrime(i) and isPrime(a-i):
            return [i,a-i]

    return [0,0]

def main():
#验证哥德巴赫猜想的程序。
    maxNum = readMax()
    for i in range(4,maxNum+1,2):
        primes = decompose(i)
        if primes == [0,0]:
            print('哥德巴赫猜想错误：' + str(i) + '不能分解为两个素数之和。')
        else:
            print('{}={}+{}'.format(i,primes[0],primes[1]))

main()

