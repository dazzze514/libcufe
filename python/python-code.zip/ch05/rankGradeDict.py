def sortDict(numDict):
    keys = list(numDict.keys())
    values = list(numDict.values())
    sortedValues = sorted(values, reverse = True)
    sortedDict = {}
    for i in sortedValues:
        rank = sortedValues.index(i) + 1
        k = values.index(i)
        sortedDict[keys[k]] = [i, rank]
    return sortedDict

grade={'Liu, D.': 89, 'Wang, E.': 95, 'Li, S.': 67, 'Chen, S.': 75}
sortedGrade = sortDict(grade)

name = input("Please input name: ").strip()
while name not in grade.keys():
    print('No such a student!')
    name = input('Please input again: ')

score = sortedGrade[name][0]
rank = sortedGrade[name][1]
print(name + ': '+ str(score)+ ' points, rank no. '+ str(rank))
