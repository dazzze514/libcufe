def  buildStudDict(studNum,**studInfo):
    studDict = {}
    studDict[studNum] = studInfo
    return studDict

studProfile = {}

number = '2020310912'
studProfile.update(buildStudDict(number, name='Liu, D.', place='Hubei',hobby='PinPong'))

number = '2020310867'
studProfile.update(buildStudDict(number,  name='Wang, E.', place='Beijing'))

number = '2020310733'
studProfile.update(buildStudDict(number,  name='Li, S.', nation='Miao'))

for key,value in studProfile.items():
    print(key+":"+str(value))
