def buildDict(keys,*values):
    listDict = []
    for value in values:
        scoreDict = {}
        for i in keys:
            scoreDict[i] = value[keys.index(i)]
        listDict.append(scoreDict)
    return listDict

scores1 = [89, 95, 67, 75]
scores2 =  [75, 79, 79, 75]
scores3 =  [85, 89, 93, 81]
classmates = ['Liu, D.','Wang, E.','Li, S.','Chen, S.']
listGrade = buildDict(classmates,scores1,scores2,scores3)
for grade in listGrade:
    print (grade)

