names = ['Sue', 'Cora', 'Beth', 'Ann', 'June']
'''选择排序'''
for i in range(0,len(names)-1):
    '''找最小'''
    min_sub = i #当前最小元素的下标位置
    for j in range(i+1, len(names)):
        if names[j] < names[min_sub]:
            min_sub = j    
    names[min_sub], names[i] = names[i], names[min_sub]
print(names)
