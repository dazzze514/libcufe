end = True
while end:
    number = int(input("请输入一个正整数："))
    test = True 
    for i in range(2,int(number**0.5)+1): 
        if number % i == 0: 
            test = False 
            break
    if test: 
        print(str(number)+"是素数。")
    else:
        print(str(number)+"不是素数。")
    cont = input("继续测试吗？（Y/N）：").lower()
    if cont != 'y':
        end = False

        
