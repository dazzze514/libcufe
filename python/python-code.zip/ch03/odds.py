message = "odds (1-100): "
for each in range(1,100,2):
    if each > 1:
        message += ","
    message += str(each)
print(message)
