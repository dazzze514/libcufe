numDayCourses = 6
monday = ['高等数学  ', '高等数学  ', '电子商务  ', '电子商务  ', 'Python编程', 'Python编程']
tuesday = ['计算机基础', '计算机基础','离散数学  ', '离散数学  ', '电子商务  ', '电子商务  ']
wednesday = ['管理学原理', '管理学原理','计算机基础', '计算机基础','高等数学  ', '高等数学  ']
thursday = ['思想政治  ', '思想政治  ','大学英语  ', '大学英语  ','专业实践  ', '专业实践  ']
friday = ['Python编程', 'Python编程', '离散数学', '离散数学','大学英语', '大学英语']
week = [monday,tuesday,wednesday,thursday,friday]
title = ['节', '星期一   ', '星期二   ', '星期三   ', '星期四   ', '星期五']
print('\t'.join(title))
for i in range(numDayCourses):
    line = [str(i+1)]
    for j in range(len(week)):
        line.append(week[j][i])
    print('\t'.join(line))
