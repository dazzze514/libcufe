from pygal_maps_world import maps
from pygal_maps_world.i18n import COUNTRIES
import pandas as pd

def get_codes(country_name, all_country_dict=COUNTRIES):
    for each in all_country_dict:
        if country_name == all_country_dict[each]:
            return each
    return None

data = pd.read_csv("gdp.csv")
gdp_2016 = data[data["Year"] == 2016]
gdp_list = [(get_codes(gdp_2016.loc[idx][0],COUNTRIES),gdp_2016.loc[idx][3]) for idx in gdp_2016.index]
gdp_list = [each for each in gdp_list if each[0]]

world_map = maps.World()
world_map.title = 'GDP of Countries'
world_map.add('GDP of Countries', gdp_list)
world_map.render_to_file("gdp_map.svg")
