import matplotlib.pyplot as plt
import numpy as np
import math
x = np.arange(0,10,0.1)
y = [math.sin(each) for each in x]
plt.plot(x, y, "r+")
plt.show()
