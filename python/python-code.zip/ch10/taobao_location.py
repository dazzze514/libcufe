import pandas as pd
import pygal as pg
data = pd.read_json("item_attributes.json", encoding="utf-8")
data = data.fillna(data.mean())
data["loc"] = data["loc"].apply(lambda x: x.strip()[:len(x) if x.find(" ")==-1 else x.find(" ")] )
data = data["price"].groupby(data["loc"])
gsum = data.sum()
gsum = gsum.reset_index()
bar = pg.Bar()
bar.add("", gsum["price"])
bar.title ="Sum Prices of Location"
bar.x_labels = gsum["loc"]
bar.x_title = 'Location'
bar.y_title = 'Sum Price'
bar.render_to_file('sum_price.svg')
