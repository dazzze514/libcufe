from pygal_maps_world import maps
from pygal_maps_world.i18n import COUNTRIES
worldmap_chart = maps.World()
worldmap_chart.title = 'C Countries'
ccodes = []
for key,value in COUNTRIES.items():
    if key.startswith("c"):
        ccodes.append(key)
        print(key,value)
worldmap_chart.add('C countries', ccodes)
worldmap_chart.render_to_file("world_map.svg")
