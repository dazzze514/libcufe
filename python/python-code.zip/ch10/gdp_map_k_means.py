﻿from pygal_maps_world import maps
from pygal_maps_world.i18n import COUNTRIES
import pandas as pd

def get_codes(country_name, all_country_dict=COUNTRIES):
    for each in all_country_dict:
        if country_name == all_country_dict[each]:
            return each
    return None

def get_k_inter_values(gdp_list, k=3): #获取gdp的k均值点
    result = []
    sorted_list = sorted([each[1] for each in gdp_list])
    for i in range(1,k):
        result.append(sorted_list[int(len(sorted_list)/(k))*i])
    return result

def get_k_level(gdp_value, k_inter): #根据k均值点分类gdp
    for i in range(len(k_inter)):
        if gdp_value < k_inter[i]:
            return i
    return len(k_inter)

def get_k_inter_gdp(gdp_list, k=3): #获取不同类的gdp列表
    result = [[] for i in range(k)]
    k_inter = get_k_inter_values(gdp_list, k)
    gdp_list = [(each[0], get_k_level(each[1], k_inter)) for each in gdp_list]
    for each in gdp_list:
        result[each[1]].append(each)
    return result

k = 3
data = pd.read_csv("gdp.csv")
gdp_2016 = data[data["Year"] == 2016]
gdp_list = [(get_codes(gdp_2016.loc[idx][0],COUNTRIES),gdp_2016.loc[idx][3]) for idx in gdp_2016.index]
gdp_list = [each for each in gdp_list if each[0]]
#k_inter = get_k_inter_values(gdp_list, k)
gdp_list = get_k_inter_gdp(gdp_list, k)
world_map = maps.World()
world_map.title = 'GDP of Countries'
for i in range(k):
    world_map.add('Type {} Countries'.format(i), gdp_list[i])
world_map.render_to_file("gdp_map_k_means.svg")

