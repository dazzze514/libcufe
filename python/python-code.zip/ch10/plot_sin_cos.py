import matplotlib.pyplot as plt
import numpy as np
import math
x1 = np.arange(0,10,0.1)
y1 = [math.sin(each) for each in x1]
x2 = np.arange(0,10,0.1)
y2 = [math.cos(each) for each in x2]
plt.plot(x1, y1, "r+", x2, y2, "bo")
plt.show()
