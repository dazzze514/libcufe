import numpy as np
import pygal as pg
x = np.arange(0,10,0.5)
y = np.sin(x)
bar = pg.Bar()
bar.add('', y)
bar.title = 'SIN Function'
bar.x_labels = [str(each) for each in x]
bar.x_title = 'x'
bar.y_title = 'sin(x)'
bar.render_to_file('bar_sin.svg')
