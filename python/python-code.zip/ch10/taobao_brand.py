import pandas as pd
import matplotlib.pyplot as plt
#若没有雅黑字体(SimHei)，会出现warning，无法显示中文
plt.rcParams['font.sans-serif'] = ['SimHei']  # 中文字体设置
plt.rcParams['axes.unicode_minus'] = False
data = pd.read_json("item_attributes.json", encoding="utf-8")
data = data.fillna(data.mean())  #处理缺失值
groups = data['price'].groupby(data['brand'])
gmeans = groups.mean()
gmeans = gmeans.reset_index()
gmeans  = gmeans.sort_values(by="price",ascending=False)
gmeans = gmeans.iloc[:6,:]
plt.title("Brands of Top 6 Average Price")
plt.ylabel("Price")
plt.xlabel("Brand")
#matplotlib版本若低于3.0，使用scatter函数可能会报错
plt.scatter(gmeans["brand"], gmeans["price"], c=gmeans["price"], s=gmeans["price"], cmap=plt.cm.get_cmap(),marker='$\clubsuit$')
plt.show()
