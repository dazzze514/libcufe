sep=input("Please input the seperator: ")
print(sep*50)
