myLastName=input("Please input your last name: ")
myFirstName=input("Please input your first name: ")
print("Hello World! My name is "+ myFirstName+" "+ myLastName+".")
