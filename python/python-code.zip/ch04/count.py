gCstring='Python/是/一门/程序/设计/的/入门/课程/，/是/您/站/在/风口/上/的/必备/良药/，/是/您/站/在/风口/上/的/必备/良药/，/是/您/站/在/风口/上/的/必备/良药/，/重要/的/事情/说/三遍/！'
g_list=gCstring.split('/')
g_dict={}
punctuations=["，","！"]

for g in g_list:
    if g not in punctuations:
        if g not in g_dict:
            g_dict[g]=1
        else:
            g_dict[g]=g_dict[g]+1
            
for k,v in g_dict.items():
    print('"'+k+'"：'+str(v)+'次')             
   
