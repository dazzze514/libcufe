classmates = ['刘达', '王尔', '李珊', '陈思','张悟']
courses = ['高等数学','Python程序设计','宏观经济学','管理学原理']

grade1 = {'刘达': 89, '王尔': 95, '李珊': 67, '陈思': 75}
grade2 = {'刘达': 75, '王尔': 79, '李珊': 79}
grade3 = {'李珊': 87, '陈思': 91,'张悟':75}
grade4 = {'刘达': 89, '王尔': 86, '张悟': 99}
grade_course = [grade1,grade2,grade3,grade4]

student1,student2,student3,student4,student5 = {},{},{},{},{}
grade_student=[student1,student2,student3,student4,student5]

for i in range(len(classmates)):
    for j in range(len(courses)):
        if grade_course[j].get(classmates[i]):
            grade_student[i][courses[j]] = grade_course[j].get(classmates[i])

for i in range(len(classmates)):
    print(classmates[i]+"选修了"+str(len(grade_student[i]))+"门课程:")
    for j in range(len(courses)):
        if grade_student[i].get(courses[j]):
            print("\t"+courses[j]+":"+str(grade_student[i].get(courses[j])))
